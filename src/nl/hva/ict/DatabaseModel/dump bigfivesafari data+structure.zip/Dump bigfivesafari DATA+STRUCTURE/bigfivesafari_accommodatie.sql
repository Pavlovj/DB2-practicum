-- MySQL dump 10.13  Distrib 8.0.29, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: bigfivesafari
-- ------------------------------------------------------
-- Server version	8.0.29

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `accommodatie`
--

DROP TABLE IF EXISTS `accommodatie`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `accommodatie` (
  `accommodatie_code` varchar(5) NOT NULL,
  `naam` varchar(45) NOT NULL,
  `stad` varchar(45) NOT NULL,
  `land` varchar(45) NOT NULL,
  `kamer` varchar(70) NOT NULL,
  `personen` int NOT NULL,
  PRIMARY KEY (`accommodatie_code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `accommodatie`
--

LOCK TABLES `accommodatie` WRITE;
/*!40000 ALTER TABLE `accommodatie` DISABLE KEYS */;
INSERT INTO `accommodatie` VALUES ('HEVO1','Etosha Village','Okaukuejo','Namibië','Standaard kamer met 2 Bedden',2),('HHIH1','Holiday Inn','Harare','Zimbabwe','Standaard kamer',3),('HIBZ1','Indigo Beach','Zanzibar','Tanzania','Swahili-stijl budget tweepersoonskamer',2),('HIBZ2','Indigo Beach','Zanzibar','Tanzania','Bungalow met uitzicht op de tuin ',8),('HPHC1','Premier Hotel Cape Town','Kaapstad','Zuid-Afrika','Familie loft met queensize bed en 2 aparte bedden',4),('HRHB1','Bulawayo Rainbow Hotel','Bulawayo','Zimbabwe','Deluxe tweepersoonskamer',2),('HRMS1','River Manor Boutique Hote','Stellen Bosch','Zuid-Afrika','Loft studio kamer',2),('HRMS2','River Manor Boutique Hote','Stellen Bosch','Zuid-Afrika','Superior tweepersoonskamer',2),('HSCW1','Safari Court Hotel','Windhoek','Namibië','Classic tweepersoonskamer met 2 aparte bedden',2),('HZBK1','Zanbluu Beach Hotel','Kiwengwa','Tanzania','Superior Suite met uitzicht op zee en eigen zwembad',2),('LAAC1','Sasa Safari Camp','Outjo','Namibië','Tweepersoonskamer met Uitzicht',2),('LASL1','Africa Safari Lodge','Mariental','Namibië','Familiekamer',4),('LBBL1','Baby Bush Lodge','Kiwengwa','Tanzania','Bruidssuite met Balkon',2),('LIEK1','Impala Ecolodge','Kisumu','Kenia','Luxe suite',2),('LIML1','Immanuel Wilderness Lodge','Windhoek','Namibië','Tweepersoonskamer met Uitzicht op de Tuin',2),('LML1','Mika Lodge','Lusaka','Zambia','Executive Suite',2),('LNZL1','Ngoma Zanga Lodge','Livingstone','Zambia','Deluxe kamer met kingsize bed',3);
/*!40000 ALTER TABLE `accommodatie` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-06-17 12:24:09
