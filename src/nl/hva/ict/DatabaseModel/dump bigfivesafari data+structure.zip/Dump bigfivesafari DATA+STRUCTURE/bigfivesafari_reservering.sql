-- MySQL dump 10.13  Distrib 8.0.29, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: bigfivesafari
-- ------------------------------------------------------
-- Server version	8.0.29

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `reservering`
--

DROP TABLE IF EXISTS `reservering`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `reservering` (
  `id_reservering` int NOT NULL,
  `accommodatie_code` varchar(5) NOT NULL,
  `reizigers_code` varchar(45) NOT NULL,
  `aankomst_datum` date NOT NULL,
  `vertrek_datum` date NOT NULL,
  `betaald` varchar(3) NOT NULL,
  PRIMARY KEY (`id_reservering`),
  KEY `fk_Reservering_Accommodatie1_idx` (`accommodatie_code`),
  KEY `fk_Reservering_Reiziger1_idx` (`reizigers_code`),
  CONSTRAINT `fk_Reservering_Accommodatie1` FOREIGN KEY (`accommodatie_code`) REFERENCES `accommodatie` (`accommodatie_code`) ON DELETE CASCADE,
  CONSTRAINT `fk_Reservering_Reiziger1` FOREIGN KEY (`reizigers_code`) REFERENCES `reiziger` (`reizigers_code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `reservering`
--

LOCK TABLES `reservering` WRITE;
/*!40000 ALTER TABLE `reservering` DISABLE KEYS */;
INSERT INTO `reservering` VALUES (1,'HIBZ2','FadilT','2022-07-12','2022-07-19','Nee'),(2,'HSCW1','JeremyD','2022-07-10','2022-07-19','Ja'),(3,'HPHC1','WongH','2022-07-31','2022-08-05','Nee'),(4,'LBBL1','FadilT','2022-07-19','2022-07-26','Nee'),(5,'LNZL1','MulderF','2022-08-12','2022-08-19','Ja'),(6,'HRHB1','NazariM','2022-07-01','2022-07-05','Nee'),(7,'LNZL1','NazariM','2022-07-05','2022-07-12','Nee'),(8,'HRMS1','NguyenR','2022-07-24','2022-07-26','Ja'),(9,'HPHC1','NguyenR','2022-07-26','2022-07-31','Ja'),(10,'LIEK1','NguyenR','2022-08-01','2022-08-08','Ja'),(11,'LAAC1','MeijerP','2022-08-19','2022-08-26','Nee'),(12,'LIML1','MeijerP','2022-08-26','2022-09-02','Nee');
/*!40000 ALTER TABLE `reservering` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-06-17 12:24:09
