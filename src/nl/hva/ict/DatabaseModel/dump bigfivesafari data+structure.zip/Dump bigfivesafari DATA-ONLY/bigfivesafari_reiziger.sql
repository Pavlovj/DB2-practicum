-- MySQL dump 10.13  Distrib 8.0.29, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: bigfivesafari
-- ------------------------------------------------------
-- Server version	8.0.29

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Dumping data for table `reiziger`
--

LOCK TABLES `reiziger` WRITE;
/*!40000 ALTER TABLE `reiziger` DISABLE KEYS */;
INSERT INTO `reiziger` VALUES ('FadilO','Omar','Fadil','Houtsberg 16','6091 NA','Leveroy','Nederland','FadilT'),('FadilT','Tahera','Fadil','Houtsberg 16','6091 NA','Leveroy','Nederland',NULL),('FonteijnC','Claar','Fonteijn','Castricummerwerf 70','1901 RF','Castricum','Nederland','MeijerP'),('JeremyB','Bram','Jeremy','Rijksstraatweg 289','3956 CP','Leersum','Nederland','JeremyD'),('JeremyD','Demitri','Jeremy','Rijksstraatweg 289','3956 CP','Leersum','Nederland',NULL),('JeremyD1','Devid','Jeremy','De Kronkels 25','3752 LM','Bunschoten','Nederland','JeremyD'),('MeijerP','Pieter ','Meijer','Expeditiestraat 2','1135 GB','Edam','Nederland',NULL),('MulderD','Derek','Mulder','Lakenblekerstraat 49A','1431 GE','Aalsmeer','Nederland','MulderF'),('MulderF','Frank','Mulder','Lakenblekerstraat 49A','1431 GE','Aalsmeer ','Nederland',NULL),('MulderS','Sophie','Mulder','Lakenblekerstraat 49A','1431 GE','Aalsmeer','Nederland','MulderF'),('NazariM','Moustafa','Nazari','Vlakdissen 12','1648 HJ','Den Goorn','Nederland',NULL),('NguyenR','Roy','Nguyen','Bukkemweg 1','5081 CT','Hilvarenbeek','Nederland',NULL),('RijenF','Fred','van Rijen','Einsteinstraat 10','1446 VG','Purmerend','Nederland','MulderF'),('WongH','Hu','Wong','Rembrandtstraat 7','3662 HN','Oud-Bijerland','Nederland',NULL);
/*!40000 ALTER TABLE `reiziger` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-06-17 12:23:23
